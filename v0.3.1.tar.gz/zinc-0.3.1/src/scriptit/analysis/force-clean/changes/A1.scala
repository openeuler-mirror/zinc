package a

object A {
  def a = "a"
}
