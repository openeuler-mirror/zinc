package b

import a._

object B {
  val b: String = A.a
}
