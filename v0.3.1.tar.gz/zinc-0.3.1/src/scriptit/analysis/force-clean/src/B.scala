package b

object B {
  val b: Int = A.a
}
