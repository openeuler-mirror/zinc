package b

object A {
  def a = 3
}
