class A {
  val a = "a"
  val x = "x"
}