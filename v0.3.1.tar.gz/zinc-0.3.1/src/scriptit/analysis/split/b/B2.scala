class B2 extends A2 {
  val b2 = a2
}