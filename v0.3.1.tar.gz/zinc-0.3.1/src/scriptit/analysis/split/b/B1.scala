class B1 extends A1 {
  val b1 = a1
}