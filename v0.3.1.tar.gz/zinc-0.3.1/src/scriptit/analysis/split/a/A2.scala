class A2 {
  val a2 = "a2"
}