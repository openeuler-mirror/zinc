class A1 {
  val a1 = "a1"
}