class C1 extends B1 {
  val c1 = b1
}