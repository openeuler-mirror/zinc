class C2 extends B2 {
  val c2 = b2
}