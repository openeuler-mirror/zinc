class B extends A {
  val b = a
}
