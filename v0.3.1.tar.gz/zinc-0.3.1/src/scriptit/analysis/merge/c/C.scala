class C {
  val c = "c"
}