class B {
  val b = "b"
}