class A {
  val a = "a"
}