class A {
    String a = "a";
}
