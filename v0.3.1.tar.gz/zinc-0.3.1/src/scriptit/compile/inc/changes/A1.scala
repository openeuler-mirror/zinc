class A {
  val x = "x"
}
